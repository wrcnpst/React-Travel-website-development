#### API GATEWAY SERVER

วิธีการ run API GATEWAY SERVER

```
cd api-gateway
npm start
```

โดย API GATEWAY SERVER จะถูก run ที่ port 5000